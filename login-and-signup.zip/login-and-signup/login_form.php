<?php
session_start();
include('include/dbcon.php');
if(isset($_POST['login']))
{
    $valid=1;
    $email = $_POST["email"];
    $pass = ($_POST["pass"]);

if($valid == 1) {

  
    $sql = "select * from reg Where password='$pass' and email='$email'";
    $result=mysqli_query($conn,$sql);
    $row=mysqli_fetch_array($result);
    $username=$row['email'];
    
 if($result==true){
  $_SESSION['username'] = $username;
header("location:index.php");
  
        }else{
     echo    $error_message= "Something went wrong!<br>";
echo "ok";
        }
                 }
                }

                ?>